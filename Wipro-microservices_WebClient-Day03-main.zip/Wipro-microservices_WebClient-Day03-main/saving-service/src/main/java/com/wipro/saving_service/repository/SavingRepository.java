package com.wipro.saving_service.repository;

import com.wipro.saving_service.entity.Saving;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface SavingRepository extends JpaRepository<Saving, Long> {
    List<Saving> findByAccount_number(String Account_number);
}
