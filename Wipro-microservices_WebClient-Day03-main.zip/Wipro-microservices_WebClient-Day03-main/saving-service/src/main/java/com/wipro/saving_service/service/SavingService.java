package com.wipro.saving_service.service;

import com.wipro.saving_service.entity.Saving;
import com.wipro.saving_service.repository.SavingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SavingService {
    @Autowired
    private SavingRepository repository;

    public Saving create(Saving saving) {
        return repository.save(saving);
    }

    public List<Saving> getSavingByAccount_number(String Account_number) {
        return repository.findByAccount_number(Account_number);
    }

    public double calculateTotalSavings(String Account_number) {
        List<Saving> savingsList = repository.findByAccount_number(Account_number);

        double totalSavings = 0;
        for (Saving saving : savingsList) {
            totalSavings += saving.getFixedDeposit();
        }

        return totalSavings;
    }
}
