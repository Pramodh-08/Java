package com.wipro.saving_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Savingsdto {
    private int fixedDeposit;
    private String mutualFunds;
    private String lifeInsurance;
    private String goldSavings;
    private String Account_number;
}
