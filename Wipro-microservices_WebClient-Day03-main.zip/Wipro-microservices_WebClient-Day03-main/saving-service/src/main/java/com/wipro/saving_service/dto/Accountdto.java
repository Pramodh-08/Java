package com.wipro.saving_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Accountdto {
    public Long id;
    public String name;
    public String Account_number;
    public String branch = "Hyderabad";
    public long isfc;
    public double balance;

}
