package com.wipro.saving_service.entity;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Saving {
    public int fixedDeposit;
    public String mutualFunds;
    public String lifeInsurance;
    public String goldSavings;
    public String Account_number;
}
