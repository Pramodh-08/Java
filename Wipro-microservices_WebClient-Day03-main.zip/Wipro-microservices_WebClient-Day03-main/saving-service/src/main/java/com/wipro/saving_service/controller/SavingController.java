package com.wipro.saving_service.controller;


import com.wipro.saving_service.dto.Accountdto;
import com.wipro.saving_service.dto.Responsedto;
import com.wipro.saving_service.dto.Savingsdto;
import com.wipro.saving_service.entity.Saving;
import com.wipro.saving_service.service.SavingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@RestController
@RequestMapping("/Saving")
public class SavingController {
    @Autowired
    private SavingService service;

    @Autowired
    private WebClient.Builder webClientBuilder;

    @PostMapping
    public Saving createSaving(@RequestBody Saving saving) {
        return service.create(saving);
    }

    @GetMapping("{Account_number}")
    public List<Saving> getSaving(@PathVariable String Account_number) {
        return service.getSavingByAccount_number(Account_number);

    }

    @GetMapping("/calculate/{Account_number}")
    public double calculateSavings(@PathVariable String Account_number) {
        return service.calculateTotalSavings(Account_number);
    }

    @GetMapping("/combined/{Account_number}")
    public Mono<Responsedto> getCombinedDetails(@PathVariable String Account_number) {

        // Fetch account details using WebClient (external call)
        Mono<List<Accountdto>> accountDetails = webClientBuilder.build()
                .get()
                .uri("http://localhost:9091/account/" + Account_number) // ensure this URL returns a list of accounts
                .retrieve()
                .bodyToFlux(Accountdto.class)
                .collectList();

        // Fetch savings details from your local service (wrap in Mono)
        Mono<List<Savingsdto>> savingsDetails = Mono.fromSupplier(() ->
                service.getSavingByAccount_number(Account_number)
                        .stream()
                        .map(saving -> new Savingsdto(
                                saving.getFixedDeposit(),
                                saving.getMutualFunds(),
                                saving.getLifeInsurance(),
                                saving.getGoldSavings(),
                                saving.getAccount_number()
                        ))
                        .toList()
        );

        // Combine both results into one Responsedto
        return Mono.zip(accountDetails, savingsDetails)
                .map(tuple -> {
                    Responsedto response = new Responsedto();
                    response.setAccountDetails(tuple.getT1());
                    response.setSavingsDetails(tuple.getT2());
                    return response;
                });
    }


}
