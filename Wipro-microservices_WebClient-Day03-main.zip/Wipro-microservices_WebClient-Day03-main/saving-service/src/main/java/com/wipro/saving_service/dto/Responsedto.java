package com.wipro.saving_service.dto;

import java.util.List;

public class Responsedto {
    private List<Accountdto> accountDetails;
    private List<Savingsdto> savingsDetails;

    public List<Accountdto> getAccountDetails() {
        return accountDetails;
    }
    public void setAccountDetails(List<Accountdto> accountDetails) {
        this.accountDetails = accountDetails;
    }
    public List<Savingsdto> getSavingsDetails() {
        return savingsDetails;
    }
    public void setSavingsDetails(List<Savingsdto> savingsDetails) {
        this.savingsDetails = savingsDetails;
    }
}
