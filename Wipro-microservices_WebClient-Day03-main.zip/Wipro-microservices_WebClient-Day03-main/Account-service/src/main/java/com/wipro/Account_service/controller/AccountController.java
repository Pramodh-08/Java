package com.wipro.Account_service.controller;

import com.wipro.Account_service.entity.Account;
import com.wipro.Account_service.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Account")
public class AccountController {
    @Autowired
    private AccountService service;

    @PostMapping
    public Account create(@RequestBody Account account){
        return service.create(account);
    }

    @GetMapping("{Account_number}")
    public List<Account> getAccount(@PathVariable String Account_number){
        return service.getAccount(Account_number);
    }
}
