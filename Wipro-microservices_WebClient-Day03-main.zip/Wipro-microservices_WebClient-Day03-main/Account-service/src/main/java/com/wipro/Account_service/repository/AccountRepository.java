package com.wipro.Account_service.repository;

import com.wipro.Account_service.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccountRepository extends JpaRepository<Account, String> {
    List<Account> findByAccount_number(String Account_number);
}
