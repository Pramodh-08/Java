package com.wipro.Account_service.entity;


import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Account {
    public String name;
    public String Account_number;
    public String branch = "Hyderabad";
    public long isfc;
    public double balance;
}
