package com.wipro.Account_service.service;

import com.wipro.Account_service.entity.Account;
import com.wipro.Account_service.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountService {
    @Autowired
    private AccountRepository accountRepository;

    public Account create(Account account){
        return accountRepository.save(account);
    }

    public List<Account> getAccount(String Account_number){
        return accountRepository.findByAccount_number(Account_number);
    }
}
