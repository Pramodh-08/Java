package com.example.collegeapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeappApplicationTests {

	@Test
	void contextLoads() {
	}

}
