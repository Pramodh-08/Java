package com.example.collegeapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegeappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegeappApplication.class, args);
	}

}
