package com.phase2.wiproDay1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproDay1ApplicationTests {

	@Test
	void contextLoads() {
	}
}
